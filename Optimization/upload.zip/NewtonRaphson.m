% Program to find roots of a function, f(x)=0 using Newton-Raphson Method
%==========================================================================
% Required Inputs:
%==========================================================================
% Function Definition (using Anonymous Function)
% Initial Guess
% Maximum number of iterations
% Relative error tolerance for variable, x
%==========================================================================
% Root of the function,x
%==========================================================================

% Version 1.0
% Date: 6th July,2018

%==========================================================================
% Developed by : Arshad Afzal, India, Email: arshad.afzal@gmail.com 
%==========================================================================

% Function Definition
%==========================================================================
 fun = @(x) x*exp(x)-1;
%==========================================================================

% Function Derivative Definition
%==========================================================================
 Derfun = @(x) (x+1)*exp(x);
%==========================================================================

fprintf('\n---Before Running this program edit the Function and its Derivative Definitions given in the problem---\n ');
fprintf('\n---Has the program been edited, chose Yes/ No---\n');

choice = menu('Answer','Yes','No');

if choice == 1
    
% Required Inputs to start the algorithm, and termination criterions
%==========================================================================
x0 = input('\nEnter the initial guess, x0 :');
Maxiter = input('\nEnter the maximum number of iterations :');
Tol = input('\nEnter the relative error tolerance for x :');
%==========================================================================

% Initialization
%==========================================================================
iter = 1;
% Vector for Storing 'x' at each iteration
x  = zeros(Maxiter,1);
% Vector for storing Function value at each iteration
funval = zeros(Maxiter,1);
% Starting guess for iteration
x(1) = x0; funval(1) = fun(x0);
% Vector for storing Realtive error in 'x' at each iteration
Err = zeros(Maxiter,1);
% Flag for Showing Iteration Information
ShowIterInfo = true;    
%==========================================================================

if isinf(fun(x0)) || isnan(Derfun(x0))
        fprintf('\n------THE FUNCTION/ DERIVATIVE VALUE MUST BE REAL AND FINITE-----\n');
        fprintf('\n--------------TRY A DIFFERENT INITIAL GUESS----------\n');
        return;
end

%==========================================================================

% Main Program
%==========================================================================
while (iter <= Maxiter)
    x(iter+1)= x(iter)-fun(x(iter))/Derfun(x(iter));
    funval(iter+1) = fun(x(iter+1));
    Err(iter) = abs((x(iter+1)-x(iter))/x(iter+1));
    
    % Display Iteration Information
        if ShowIterInfo
            disp(['Iteration ' num2str(iter) ' : x =' num2str(x(iter+1)) ' RELATIVE ERROR = ' num2str(Err(iter))]);
        end
        
    % Check for Relative error in the variable,x   
    if (Err(iter)< Tol)
        fprintf('\n -----CHANGE IN VARIABLE VALUE LESS THAN SPECIFIED TOLERANCE-----\n');
        break;
    end
   
    if (iter == Maxiter)
        fprintf('\n -----MAXIMUM NUMBER OF ITERATIONS REACHED-----\n');
        break;
    end
    iter = iter+1;
end

Sol = x(iter+1)
Functionvalue = funval(iter+1)
else
        fprintf('\n -----------EDIT THE FUNCTION AND ITS DERIVATIVE DEFINITIONS TO PROCEED-----------\n');
end